/**
 * MultipleDarkNews Education & Academic Calculation Engine
 */

export interface CourseGrade {
  courseName: string;
  credits: number;
  grade: string;
}

const GRADE_POINTS: Record<string, number> = {
  'A+': 4.0,
  A: 4.0,
  'A-': 3.7,
  'B+': 3.3,
  B: 3.0,
  'B-': 2.7,
  'C+': 2.3,
  C: 2.0,
  'C-': 1.7,
  'D+': 1.3,
  D: 1.0,
  F: 0.0,
};

/**
 * Calculate GPA from courses
 */
export function calculateGpa(courses: CourseGrade[]): {
  gpa: number;
  totalCredits: number;
  totalPoints: number;
  gradeScale: string;
} {
  let totalCredits = 0;
  let totalPoints = 0;

  for (const c of courses) {
    const pts = GRADE_POINTS[c.grade.toUpperCase()] ?? 0;
    totalPoints += pts * c.credits;
    totalCredits += c.credits;
  }

  const gpa = totalCredits > 0 ? Number((totalPoints / totalCredits).toFixed(2)) : 0;

  return {
    gpa,
    totalCredits,
    totalPoints: Number(totalPoints.toFixed(2)),
    gradeScale: 'Standard 4.0 GPA Scale',
  };
}

/**
 * Marks / Percentage Calculator
 */
export function calculateMarksPercentage(obtained: number, maximum: number): {
  percentage: number;
  grade: string;
  fraction: string;
} {
  if (maximum <= 0) return { percentage: 0, grade: 'N/A', fraction: '0/0' };
  const percentage = Number(((obtained / maximum) * 100).toFixed(2));

  let grade = 'F';
  if (percentage >= 90) grade = 'A+ (Distinction)';
  else if (percentage >= 80) grade = 'A (Excellent)';
  else if (percentage >= 70) grade = 'B (Good)';
  else if (percentage >= 60) grade = 'C (Satisfactory)';
  else if (percentage >= 50) grade = 'D (Pass)';

  return {
    percentage,
    grade,
    fraction: `${obtained} / ${maximum}`,
  };
}
