import React, { useEffect } from 'react';

export interface BreadcrumbItem {
  name: string;
  url: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface HowToStep {
  name: string;
  text: string;
}

interface SEOHeadProps {
  title: string;
  description: string;
  canonicalUrl?: string;
  keywords?: string[];
  ogType?: 'website' | 'article';
  ogImage?: string;
  breadcrumbs?: BreadcrumbItem[];
  faq?: FaqItem[];
  howToSteps?: HowToStep[];
  toolCategory?: string;
  toolName?: string;
  ratingValue?: number;
  ratingCount?: number;
  noIndex?: boolean;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  title,
  description,
  canonicalUrl,
  keywords,
  ogType = 'website',
  ogImage = 'https://multipledarknews.com/og-image.png',
  breadcrumbs,
  faq,
  howToSteps,
  toolCategory,
  toolName,
  ratingValue = 4.9,
  ratingCount = 1420,
  noIndex = false,
}) => {
  useEffect(() => {
    // 1. Title
    document.title = title;

    // Helper for meta tags
    const setMeta = (nameOrProp: string, content: string, isProp = false) => {
      const attr = isProp ? 'property' : 'name';
      let el = document.querySelector(`meta[${attr}="${nameOrProp}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, nameOrProp);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    // 2. Standard Meta Tags
    setMeta('description', description);
    if (keywords && keywords.length > 0) {
      setMeta('keywords', keywords.join(', '));
    }
    setMeta('robots', noIndex ? 'noindex, nofollow' : 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
    setMeta('author', 'MultipleDarkNews Tools Platform');

    // 3. Canonical Link
    const url = canonicalUrl || (typeof window !== 'undefined' ? window.location.href : 'https://multipledarknews.com');
    let canonicalTag = document.querySelector('link[rel="canonical"]');
    if (!canonicalTag) {
      canonicalTag = document.createElement('link');
      canonicalTag.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalTag);
    }
    canonicalTag.setAttribute('href', url);

    // 4. OpenGraph Tags
    setMeta('og:type', ogType, true);
    setMeta('og:title', title, true);
    setMeta('og:description', description, true);
    setMeta('og:url', url, true);
    setMeta('og:site_name', 'MultipleDarkNews Tools', true);
    setMeta('og:image', ogImage, true);
    setMeta('og:locale', 'en_US', true);

    // 5. Twitter Card Tags
    setMeta('twitter:card', 'summary_large_image');
    setMeta('twitter:title', title);
    setMeta('twitter:description', description);
    setMeta('twitter:image', ogImage);
    setMeta('twitter:site', '@MultipleDarkNews');
    setMeta('twitter:creator', '@MultipleDarkNews');

    // 6. Schema.org JSON-LD Structured Data Graph
    const schemaGraph: any[] = [
      // Organization Schema
      {
        '@type': 'Organization',
        '@id': 'https://multipledarknews.com/#organization',
        name: 'MultipleDarkNews',
        url: 'https://multipledarknews.com',
        logo: {
          '@type': 'ImageObject',
          url: 'https://multipledarknews.com/logo.png',
        },
        sameAs: ['https://twitter.com/MultipleDarkNews'],
      },
      // WebSite with SearchAction
      {
        '@type': 'WebSite',
        '@id': 'https://multipledarknews.com/#website',
        url: 'https://multipledarknews.com',
        name: 'MultipleDarkNews Tools',
        description: 'Complete suite of 325+ free online PDF, image, developer, SEO, and calculation tools.',
        publisher: {
          '@id': 'https://multipledarknews.com/#organization',
        },
        potentialAction: {
          '@type': 'SearchAction',
          target: {
            '@type': 'EntryPoint',
            urlTemplate: 'https://multipledarknews.com/#search?q={search_term_string}',
          },
          'query-input': 'required name=search_term_string',
        },
      },
    ];

    // If on a Tool Page: Add WebApplication / SoftwareApplication Schema
    if (toolName) {
      schemaGraph.push({
        '@type': 'WebApplication',
        '@id': `${url}#app`,
        name: toolName,
        url: url,
        applicationCategory: toolCategory ? `${toolCategory}Application` : 'UtilityApplication',
        operatingSystem: 'All (Web Browser, Windows, macOS, Linux, iOS, Android)',
        description: description,
        browserRequirements: 'Requires JavaScript. Requires HTML5.',
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
          availability: 'https://schema.org/InStock',
        },
        aggregateRating: {
          '@type': 'AggregateRating',
          ratingValue: ratingValue.toString(),
          reviewCount: ratingCount.toString(),
          bestRating: '5',
          worstRating: '1',
        },
      });
    }

    // BreadcrumbList Schema
    if (breadcrumbs && breadcrumbs.length > 0) {
      schemaGraph.push({
        '@type': 'BreadcrumbList',
        '@id': `${url}#breadcrumb`,
        itemListElement: breadcrumbs.map((b, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          name: b.name,
          item: b.url,
        })),
      });
    }

    // FAQPage Schema (for Google SERP Rich FAQ Dropdowns)
    if (faq && faq.length > 0) {
      schemaGraph.push({
        '@type': 'FAQPage',
        '@id': `${url}#faq`,
        mainEntity: faq.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      });
    }

    // HowTo Schema (for Google SERP Step-by-Step Rich Guides)
    if (howToSteps && howToSteps.length > 0) {
      schemaGraph.push({
        '@type': 'HowTo',
        '@id': `${url}#howto`,
        name: `How to use ${toolName || 'this tool'} online`,
        description: `Step-by-step instructions for using ${toolName || 'tool'} for free with zero installation.`,
        step: howToSteps.map((step, idx) => ({
          '@type': 'HowToStep',
          position: idx + 1,
          name: step.name,
          text: step.text,
        })),
      });
    }

    // Inject into head
    let scriptTag = document.getElementById('seo-json-ld');
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = 'seo-json-ld';
      scriptTag.setAttribute('type', 'application/ld+json');
      document.head.appendChild(scriptTag);
    }

    scriptTag.textContent = JSON.stringify({
      '@context': 'https://schema.org',
      '@graph': schemaGraph,
    });
  }, [
    title,
    description,
    canonicalUrl,
    keywords,
    ogType,
    ogImage,
    breadcrumbs,
    faq,
    howToSteps,
    toolCategory,
    toolName,
    ratingValue,
    ratingCount,
  ]);

  return null;
};
